import React, { useState, useRef } from 'react';
    import { motion } from 'framer-motion';
    import { Progress } from '@/components/ui/progress';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Edit3, FileText, FileImage as ImageIcon, Award, Languages as LanguagesIcon, Bot, CheckCircle } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import html2canvas from 'html2canvas';
    import jsPDF from 'jspdf';

    import PersonalInfoStep from '@/components/cv-form-steps/PersonalInfoStep';
    import ExperienceStep from '@/components/cv-form-steps/ExperienceStep';
    import EducationStep from '@/components/cv-form-steps/EducationStep';
    import SkillsStep from '@/components/cv-form-steps/SkillsStep';
    import ProjectsStep from '@/components/cv-form-steps/ProjectsStep';
    import CertificationsStep from '@/components/cv-form-steps/CertificationsStep.jsx';
    import LanguagesStep from '@/components/cv-form-steps/LanguagesStep.jsx';
    import ProfilePictureStep from '@/components/cv-form-steps/ProfilePictureStep';
    import PreviewStep from '@/components/cv-form-steps/PreviewStep';

    import ConversationalEducationStep from '@/components/cv-form-steps/ConversationalEducationStep';
    import ConversationalExperienceStep from '@/components/cv-form-steps/ConversationalExperienceStep';
    import ConversationalSkillsStep from '@/components/cv-form-steps/ConversationalSkillsStep';
    import ConversationalLanguagesStep from '@/components/cv-form-steps/ConversationalLanguagesStep';
    import ConversationalInterestsStep from '@/components/cv-form-steps/ConversationalInterestsStep';
    import ConversationalOtherInfoStep from '@/components/cv-form-steps/ConversationalOtherInfoStep';

    import useCVStore from '@/hooks/useCVStore';
    import ModeSelection from '@/components/home/ModeSelection.jsx';
    import StepRenderer from '@/components/home/StepRenderer.jsx';
    import NavigationControls from '@/components/home/NavigationControls.jsx';
    import CVGenerator from '@/lib/cvGenerator';

    const formStepsConfig = [
      { id: 'personalInfo', title: 'Información Personal', icon: Edit3, component: PersonalInfoStep },
      { id: 'profilePicture', title: 'Foto de Perfil', icon: ImageIcon, component: ProfilePictureStep },
      { id: 'experience', title: 'Experiencia Laboral', icon: Edit3, component: ExperienceStep },
      { id: 'education', title: 'Educación', icon: Edit3, component: EducationStep },
      { id: 'skills', title: 'Habilidades', icon: Edit3, component: SkillsStep },
      { id: 'projects', title: 'Proyectos', icon: Edit3, component: ProjectsStep },
      { id: 'certifications', title: 'Certificaciones', icon: Award, component: CertificationsStep },
      { id: 'languages', title: 'Idiomas', icon: LanguagesIcon, component: LanguagesStep },
      { id: 'preview', title: 'Previsualizar y Descargar', icon: FileText, component: PreviewStep },
    ];

    const conversationalStepsConfig = [
      { id: 'personalInfo', title: 'Información Personal', icon: Bot, component: PersonalInfoStep }, 
      { id: 'profilePicture', title: 'Foto de Perfil', icon: ImageIcon, component: ProfilePictureStep },
      { id: 'conversationalEducation', title: 'Educación (Conversacional)', icon: Bot, component: ConversationalEducationStep },
      { id: 'conversationalExperience', title: 'Experiencia (Conversacional)', icon: Bot, component: ConversationalExperienceStep },
      { id: 'conversationalSkills', title: 'Habilidades (Conversacional)', icon: Bot, component: ConversationalSkillsStep },
      { id: 'conversationalLanguages', title: 'Idiomas (Conversacional)', icon: Bot, component: ConversationalLanguagesStep },
      { id: 'conversationalInterests', title: 'Intereses (Conversacional)', icon: Bot, component: ConversationalInterestsStep },
      { id: 'conversationalOtherInfo', title: 'Otra Información (Conversacional)', icon: Bot, component: ConversationalOtherInfoStep },
      { id: 'preview', title: 'Previsualizar y Descargar', icon: FileText, component: PreviewStep },
    ];

    const HomePage = () => {
      const cvStoreData = useCVStore();
      const { cvData, resetCVData } = cvStoreData;
      const [currentStepIndex, setCurrentStepIndex] = useState(0);
      const [mode, setMode] = useState(null); 
      const { toast } = useToast();
      const cvPreviewRef = useRef(null);
      const [isDownloading, setIsDownloading] = useState(false);

      const steps = mode === 'form' ? formStepsConfig : (mode === 'conversational' ? conversationalStepsConfig : []);
      
      const handleNext = () => {
        if (currentStepIndex < steps.length - 1) {
          setCurrentStepIndex(prev => prev + 1);
        } else {
          toast({
            title: "¡Completado!",
            description: "Has llegado al final. Revisa tu CV y descárgalo.",
            className: "bg-green-100 dark:bg-green-800 border-green-300 dark:border-green-600",
            action: <CheckCircle className="text-green-500" />,
          });
        }
      };

      const handleBack = () => {
        if (currentStepIndex > 0) {
          setCurrentStepIndex(prev => prev - 1);
        }
      };

      const handleModeSelection = (selectedMode) => {
        setMode(selectedMode);
        setCurrentStepIndex(0); 
      };
      
      const handleReset = () => {
        resetCVData();
        setCurrentStepIndex(0);
        setMode(null);
        toast({
          title: "Formulario Reiniciado",
          description: "Todos los datos han sido borrados.",
        });
      };

      const downloadPDF = async () => {
        if (isDownloading || !cvPreviewRef.current) {
          if (!cvPreviewRef.current) {
            toast({ title: "Error", description: "Vista previa no disponible.", variant: "destructive"});
          }
          return;
        }
        setIsDownloading(true);
        toast({ title: "Preparando PDF...", description: "Esto puede tardar unos segundos." });

        try {
            await CVGenerator.downloadCVAsPDF(cvPreviewRef.current, cvData.personalInfo.fullName || 'CV');
            toast({
                title: "¡PDF Descargado!",
                description: "Tu CV ha sido guardado.",
                className: "bg-green-100 dark:bg-green-800 border-green-300 dark:border-green-600",
                action: <CheckCircle className="text-green-500" />,
            });
        } catch (error) {
            console.error("Error al generar PDF:", error);
            toast({
                title: "Error al generar PDF",
                description: `Ocurrió un problema: ${error.message || 'Inténtalo de nuevo.'}`,
                variant: "destructive",
            });
        } finally {
            setIsDownloading(false);
        }
    };


      const progress = steps.length > 0 ? ((currentStepIndex + 1) / steps.length) * 100 : 0;

      if (!mode) {
        return <ModeSelection onModeSelect={handleModeSelection} />;
      }
      
      const currentStepConfig = steps[currentStepIndex];
      const IconComponent = currentStepConfig?.icon || Edit3;

      return (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-4xl mx-auto p-2 sm:p-0"
        >
          <Card className="shadow-2xl bg-white/80 dark:bg-slate-800/70 backdrop-blur-md border-slate-200 dark:border-slate-700/50 overflow-hidden">
            <CardHeader className="border-b border-slate-200 dark:border-slate-700/50 p-4 sm:p-5">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <IconComponent className="h-7 w-7 text-primary mr-2.5" />
                  <CardTitle className="text-xl sm:text-2xl font-semibold text-slate-800 dark:text-gray-100">
                    {currentStepConfig?.title || 'Paso Actual'}
                  </CardTitle>
                </div>
                <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  Paso {currentStepIndex + 1} de {steps.length}
                </span>
              </div>
              <Progress value={progress} className="w-full h-2 [&>div]:bg-gradient-to-r [&>div]:from-teal-400 [&>div]:to-cyan-500" />
            </CardHeader>

            <CardContent className="p-3 sm:p-5 min-h-[300px] sm:min-h-[400px] flex flex-col justify-center items-center">
              <StepRenderer
                currentStepIndex={currentStepIndex}
                CurrentStepComponent={currentStepConfig?.component}
                cvStoreData={cvStoreData}
                onStepComplete={handleNext}
                cvPreviewRef={currentStepConfig?.id === 'preview' ? cvPreviewRef : undefined}
                downloadPDF={currentStepConfig?.id === 'preview' ? downloadPDF : undefined}
                isDownloading={currentStepConfig?.id === 'preview' ? isDownloading : undefined}
              />
            </CardContent>

            <NavigationControls
              currentStepIndex={currentStepIndex}
              isLastStep={currentStepConfig?.id === 'preview'}
              onBack={handleBack}
              onNext={handleNext}
              onReset={handleReset}
            />
          </Card>
        </motion.div>
      );
    };

    export default HomePage;